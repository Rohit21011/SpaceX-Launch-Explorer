// src/types/auth.types.ts

export interface User {
    id: string;
    username: string;
    name: string;
    role: string;
  }
  
  export interface Credentials {
    username: string;
    password: string;
  }
  
  export interface AuthResponse {
    user: User;
    token: string;
  }
  
  export interface AuthState {
    isAuthenticated: boolean;
    user: User | null;
    token: string | null;
    login: (userData: AuthResponse) => void;
    logout: () => void;
  }