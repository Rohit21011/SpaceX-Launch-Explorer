// src/store/authStore.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';

// User interface definition
export interface User {
  id: string;
  username: string;
  email: string;
  role: 'admin' | 'user';
}

// Authentication response from API
export interface AuthResponse {
  user: User;
  token: string;
}

// Auth state interface
export interface AuthState {
  isAuthenticated: boolean;
  user: User | null;
  token: string | null;
  
  // Actions
  login: (userData: AuthResponse) => void;
  logout: () => void;
  updateUser: (user: User) => void;
}

/**
 * Authentication store with persistence
 * Manages login state, user data, and authentication token
 */
const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      isAuthenticated: false,
      user: null,
      token: null,
      
      login: (userData: AuthResponse) => set({
        isAuthenticated: true,
        user: userData.user,
        token: userData.token
      }),
      
      logout: () => set({
        isAuthenticated: false,
        user: null,
        token: null
      }),
      
      updateUser: (user: User) => set((state) => ({
        ...state,
        user
      })),
    }),
    {
      name: 'spacex-auth-storage', // Name for localStorage
      partialize: (state) => ({
        isAuthenticated: state.isAuthenticated,
        user: state.user,
        token: state.token,
      }),
    }
  )
);

export default useAuthStore;