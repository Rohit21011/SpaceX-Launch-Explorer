// src/App.tsx
import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { MantineProvider, ColorSchemeProvider, ColorScheme, AppShell, Header, Text, Group, Container, ActionIcon, Button, Flex } from '@mantine/core';
import { IconRocket, IconSun, IconMoon, IconLogout } from '@tabler/icons-react';

// Pages
import HomePage from './pages/HomePage';
import LoginPage from './pages/LoginPage';
import LaunchesPage from './pages/LaunchesPage';
import LaunchDetailPage from './pages/LaunchDetailPage';

// Components
import ProtectedRoute from './components/auth/ProtectedRoute';

// Hooks
import useAuthStore from './store/authStore';

// Create a React Query client
const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      retry: 1,
      staleTime: 1000 * 60 * 5, // 5 minutes
    },
  },
});

export default function App() {
  const [colorScheme, setColorScheme] = useState<ColorScheme>('light');
  const { isAuthenticated, logout } = useAuthStore();
  
  const toggleColorScheme = (value?: ColorScheme) => {
    setColorScheme(value || (colorScheme === 'dark' ? 'light' : 'dark'));
  };

  return (
    <QueryClientProvider client={queryClient}>
      <ColorSchemeProvider colorScheme={colorScheme} toggleColorScheme={toggleColorScheme}>
        <MantineProvider theme={{ colorScheme }} withGlobalStyles withNormalizeCSS>
          <Router>
            <AppShell
              padding="md"
              header={
                <Header height={60} p="xs">
                  <Container size="xl">
                    <Group justify="space-between">
                      <Group>
                        <IconRocket size={30} />
                        <Text fw={700} size="lg">SpaceX Explorer</Text>
                      </Group>
                      
                      <Group>
                        {isAuthenticated && (
                          <>
                            <Button
                              component="a"
                              href="/launches"
                              variant="subtle"
                            >
                              Launches
                            </Button>
                            
                            <Button
                              variant="subtle"
                              color="red"
                              leftSection={<IconLogout size={16} />}
                              onClick={() => logout()}
                            >
                              Log Out
                            </Button>
                          </>
                        )}
                        
                        <ActionIcon
                          variant="outline"
                          color={colorScheme === 'dark' ? 'yellow' : 'blue'}
                          onClick={() => toggleColorScheme()}
                          title="Toggle color scheme"
                        >
                          {colorScheme === 'dark' ? <IconSun size={18} /> : <IconMoon size={18} />}
                        </ActionIcon>
                      </Group>
                    </Group>
                  </Container>
                </Header>
              }
              styles={(theme) => ({
                main: {
                  backgroundColor: theme.colorScheme === 'dark' ? theme.colors.dark[8] : theme.colors.gray[0],
                  minHeight: 'calc(100vh - 60px)',
                },
              })}
            >
              <Routes>
                {/* Public routes */}
                <Route path="/login" element={<LoginPage />} />
                
                {/* Protected routes */}
                <Route path="/" element={
                  <ProtectedRoute>
                    <HomePage />
                  </ProtectedRoute>
                } />
                
                <Route path="/launches" element={
                  <ProtectedRoute>
                    <LaunchesPage />
                  </ProtectedRoute>
                } />
                
                <Route path="/launches/:id" element={
                  <ProtectedRoute>
                    <LaunchDetailPage />
                  </ProtectedRoute>
                } />
                
                {/* Redirect to home if authenticated, otherwise to login */}
                <Route path="*" element={
                  isAuthenticated ? <Navigate to="/" replace /> : <Navigate to="/login" replace />
                } />
              </Routes>
            </AppShell>
          </Router>
        </MantineProvider>
      </ColorSchemeProvider>
    </QueryClientProvider>
  );
}