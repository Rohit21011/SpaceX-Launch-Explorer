// src/pages/LaunchesPage.tsx
import { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Container,
  Title,
  Grid,
  Card,
  Image,
  Text,
  Badge,
  Group,
  Button,
  Select,
  Checkbox,
  Loader,
  Pagination,
  Stack,
  Alert,
  Flex,
  Paper,
  TextInput,
  Box,
} from '@mantine/core';
import { DatePickerInput } from '@mantine/dates';
import { IconAlertCircle, IconSearch, IconRocket, IconCalendar } from '@tabler/icons-react';
import dayjs from 'dayjs';
import { useLaunches } from '../hooks/useLaunchData';
import { useRockets } from '../hooks/useRocketData';
import { FilterOptions, PaginationOptions } from '../api/types';

export default function LaunchesPage() {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  
  // Parse search params for deep linking and persistence
  const initialPage = parseInt(searchParams.get('page') || '1');
  const initialLimit = parseInt(searchParams.get('limit') || '8');
  const initialUpcoming = searchParams.get('upcoming') === 'true';
  const initialSuccess = searchParams.get('success') === 'true';
  const initialRocket = searchParams.get('rocket') || '';
  const initialSearch = searchParams.get('search') || '';
  const initialStartDate = searchParams.get('startDate') || '';
  const initialEndDate = searchParams.get('endDate') || '';
  
  // Pagination state
  const [pagination, setPagination] = useState<PaginationOptions>({
    page: initialPage,
    limit: initialLimit,
  });
  
  // Filter state
  const [filters, setFilters] = useState<FilterOptions & { search: string }>({
    upcoming: initialUpcoming,
    success: initialSuccess,
    rocket: initialRocket,
    startDate: initialStartDate,
    endDate: initialEndDate,
    search: initialSearch,
  });
  
  // Date range picker state
  const [dateRange, setDateRange] = useState<[Date | null, Date | null]>([
    initialStartDate ? new Date(initialStartDate) : null,
    initialEndDate ? new Date(initialEndDate) : null,
  ]);
  
  // Fetch launches with filters and pagination
  const { data: launches, isLoading, isError, error } = useLaunches(pagination, filters);
  
  // Fetch rockets for the filter dropdown
  const { data: rockets } = useRockets();
  
  // Update URL search params when filters or pagination change
  useEffect(() => {
    const params = new URLSearchParams();
    
    params.set('page', pagination.page?.toString() || '1');
    params.set('limit', pagination.limit?.toString() || '8');
    
    if (filters.upcoming !== undefined) params.set('upcoming', filters.upcoming.toString());
    if (filters.success !== undefined) params.set('success', filters.success.toString());
    if (filters.rocket) params.set('rocket', filters.rocket);
    if (filters.search) params.set('search', filters.search);
    if (filters.startDate) params.set('startDate', filters.startDate);
    if (filters.endDate) params.set('endDate', filters.endDate);
    
    setSearchParams(params);
  }, [pagination, filters, setSearchParams]);
  
  // Apply filters handler
  const handleApplyFilters = () => {
    setPagination(prev => ({ ...prev, page: 1 })); // Reset to first page on filter change
    setFilters(prev => ({
      ...prev,
      startDate: dateRange[0] ? dayjs(dateRange[0]).format('YYYY-MM-DD') : '',
      endDate: dateRange[1] ? dayjs(dateRange[1]).format('YYYY-MM-DD') : '',
    }));
  };
  
  // Reset filters handler
  const handleResetFilters = () => {
    setPagination({ page: 1, limit: 8 });
    setFilters({
      upcoming: undefined,
      success: undefined,
      rocket: '',
      startDate: '',
      endDate: '',
      search: '',
    });
    setDateRange([null, null]);
  };
  
  // Navigate to launch details
  const handleLaunchClick = (id: string) => {
    navigate(`/launches/${id}`);
  };
  
  // Render rocket options for select
  const rocketOptions = rockets ? [
    { value: '', label: 'All Rockets' }, 
    ...rockets.map(rocket => ({ value: rocket.id, label: rocket.name }))
  ] : [{ value: '', label: 'Loading rockets...' }];
  
  return (
    <Container size="xl" py="xl">
      <Title order={1} mb="lg">SpaceX Launches</Title>
      
      {/* Filters */}
      <Paper shadow="sm" p="md" mb="xl" withBorder>
        <Grid>
          <Grid.Col span={12}>
            <Title order={4} mb="sm"><IconSearch size={20} /> Search & Filters</Title>
          </Grid.Col>
          
          <Grid.Col span={{ base: 12, md: 4 }}>
            <TextInput
              label="Search Launches"
              placeholder="Search by name"
              value={filters.search}
              onChange={(e) => setFilters(prev => ({ ...prev, search: e.target.value }))}
              mb="md"
            />
          </Grid.Col>
          
          <Grid.Col span={{ base: 12, md: 4 }}>
            <Select
              label="Rocket"
              placeholder="Select Rocket"
              data={rocketOptions}
              value={filters.rocket}
              onChange={(value) => setFilters(prev => ({ ...prev, rocket: value || '' }))}
              mb="md"
              icon={<IconRocket size={16} />}
            />
          </Grid.Col>
          
          <Grid.Col span={{ base: 12, md: 4 }}>
            <DatePickerInput
              type="range"
              label="Date Range"
              placeholder="Select date range"
              value={dateRange}
              onChange={setDateRange}
              mb="md"
              icon={<IconCalendar size={16} />}
            />
          </Grid.Col>
          
          <Grid.Col span={{ base: 6, md: 3 }}>
            <Checkbox
              label="Upcoming Only"
              checked={filters.upcoming === true}
              onChange={(e) => setFilters(prev => ({ ...prev, upcoming: e.currentTarget.checked }))}
              mb="md"
            />
          </Grid.Col>
          
          <Grid.Col span={{ base: 6, md: 3 }}>
            <Checkbox
              label="Successful Only"
              checked={filters.success === true}
              onChange={(e) => setFilters(prev => ({ ...prev, success: e.currentTarget.checked }))}
              mb="md"
            />
          </Grid.Col>
          
          <Grid.Col span={12}>
            <Group justify="flex-end">
              <Button variant="outline" onClick={handleResetFilters}>Reset</Button>
              <Button onClick={handleApplyFilters}>Apply Filters</Button>
            </Group>
          </Grid.Col>
        </Grid>
      </Paper>
      
      {/* Error state */}
      {isError && (
        <Alert icon={<IconAlertCircle size={16} />} title="Error" color="red" mb="xl">
          Failed to load launches: {error instanceof Error ? error.message : 'Unknown error'}
        </Alert>
      )}
      
      {/* Loading state */}
      {isLoading && (
        <Flex justify="center" align="center" h={200}>
          <Loader size="lg" />
        </Flex>
      )}
      
      {/* No results */}
      {!isLoading && launches && launches.length === 0 && (
        <Alert title="No launches found" color="blue" mb="xl">
          No launches match your current filter criteria. Try adjusting your filters.
        </Alert>
      )}
      
      {/* Launches grid */}
      {!isLoading && launches && launches.length > 0 && (
        <Grid>
          {launches.map((launch) => (
            <Grid.Col key={launch.id} span={{ base: 12, xs: 6, md: 4, lg: 3 }}>
              <Card shadow="sm" padding="lg" radius="md" withBorder h="100%">
                <Card.Section>
                  {launch.links.patch.small ? (
                    <Image
                      src={launch.links.patch.small}
                      height={160}
                      alt={launch.name}
                      fit="contain"
                      bg="gray.1"
                    />
                  ) : (
                    <Flex h={160} align="center" justify="center" bg="gray.1">
                      <IconRocket size={64} stroke={1.5} />
                    </Flex>
                  )}
                </Card.Section>
                
                <Text fw={500} size="lg" mt="md" mb="xs">
                  {launch.name}
                </Text>
                
                <Group mb="md">
                  <Badge color={launch.upcoming ? 'blue' : launch.success ? 'green' : 'red'}>
                    {launch.upcoming ? 'Upcoming' : launch.success ? 'Success' : 'Failed'}
                  </Badge>
                  <Badge color="gray">#{launch.flight_number}</Badge>
                </Group>
                
                <Text size="sm" color="dimmed" mb="md" lineClamp={2}>
                  {launch.details || 'No details available'}
                </Text>
                
                <Text size="sm" mb="md">
                  <b>Date:</b> {new Date(launch.date_utc).toLocaleDateString()}
                </Text>
                
                <Button
                  fullWidth
                  onClick={() => handleLaunchClick(launch.id)}
                  variant="light"
                  color="blue"
                  mt="auto"
                >
                  View Details
                </Button>
              </Card>
            </Grid.Col>
          ))}
        </Grid>
      )}
      
      {/* Pagination */}
      {!isLoading && launches && launches.length > 0 && (
        <Flex justify="center" mt="xl">
          <Pagination
            total={Math.ceil(100 / (pagination.limit || 10))} // Approximation for total pages
            value={pagination.page || 1}
            onChange={(page) => setPagination(prev => ({ ...prev, page }))}
          />
        </Flex>
      )}