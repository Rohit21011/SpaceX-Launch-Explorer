// src/pages/LaunchDetailPage.tsx
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Container, 
  Title, 
  Group, 
  Badge, 
  Text, 
  Image, 
  Stack, 
  Grid, 
  Paper, 
  Divider, 
  Button, 
  Tabs, 
  Skeleton, 
  Avatar, 
  Timeline, 
  ThemeIcon, 
  List, 
  Alert, 
  Card,
  Box,
  Flex,
  Anchor
} from '@mantine/core';
import { useLaunchWithRocket } from '../hooks/useLaunchData';
import { 
  IconRocket, 
  IconCalendar, 
  IconLink, 
  IconAlertCircle, 
  IconClock, 
  IconChevronLeft, 
  IconBrandYoutube, 
  IconWorld, 
  IconPhoto, 
  IconArrowBack, 
  IconCheck, 
  IconX, 
  IconInfoCircle
} from '@tabler/icons-react';

export default function LaunchDetailPage() {
  const { id = '' } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  // Fetch launch with rocket details (enriched data)
  const { data: launch, isLoading, isError, error } = useLaunchWithRocket(id);
  
  // Handle back button click
  const handleBackClick = () => {
    navigate('/launches');
  };
  
  // Format date for display
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };
  
  // Loading state
  if (isLoading) {
    return (
      <Container size="xl" py="xl">
        <Button 
          leftSection={<IconChevronLeft size={16} />} 
          variant="subtle" 
          mb="xl"
          onClick={handleBackClick}
        >
          Back to Launches
        </Button>
        
        <Skeleton height={50} mb="lg" />
        <Grid>
          <Grid.Col span={{ base: 12, md: 4 }}>
            <Skeleton height={300} mb="md" />
          </Grid.Col>
          <Grid.Col span={{ base: 12, md: 8 }}>
            <Skeleton height={30} mb="sm" />
            <Skeleton height={20} mb="sm" />
            <Skeleton height={20} mb="sm" />
            <Skeleton height={20} mb="sm" />
            <Skeleton height={100} mb="lg" />
          </Grid.Col>
        </Grid>
      </Container>
    );
  }
  
  // Error state
  if (isError) {
    return (
      <Container size="xl" py="xl">
        <Button 
          leftSection={<IconChevronLeft size={16} />} 
          variant="subtle" 
          mb="xl"
          onClick={handleBackClick}
        >
          Back to Launches
        </Button>
        
        <Alert icon={<IconAlertCircle size={16} />} title="Error" color="red">
          Failed to load launch details: {error instanceof Error ? error.message : 'Unknown error'}
        </Alert>
      </Container>
    );
  }
  
  // No data state
  if (!launch) {
    return (
      <Container size="xl" py="xl">
        <Button 
          leftSection={<IconChevronLeft size={16} />} 
          variant="subtle" 
          mb="xl"
          onClick={handleBackClick}
        >
          Back to Launches
        </Button>
        
        <Alert icon={<IconAlertCircle size={16} />} title="Not Found" color="blue">
          Launch not found. It may have been removed or the ID is incorrect.
        </Alert>
      </Container>
    );
  }
  
  return (
    <Container size="xl" py="xl">
      {/* Back button */}
      <Button 
        leftSection={<IconChevronLeft size={16} />} 
        variant="subtle" 
        mb="xl"
        onClick={handleBackClick}
      >
        Back to Launches
      </Button>
      
      {/* Launch header */}
      <Paper shadow="sm" p="lg" withBorder mb="xl">
        <Grid>
          <Grid.Col span={{ base: 12, md: 4 }}>
            <Flex direction="column" align="center">
              {launch.links.patch.large ? (
                <Image
                  src={launch.links.patch.large}
                  alt={launch.name}
                  fit="contain"
                  h={200}
                />
              ) : (
                <Flex h={200} w="100%" justify="center" align="center" bg="gray.1">
                  <IconRocket size={100} stroke={1.5} />
                </Flex>
              )}
              
              <Group mt="md">
                <Badge 
                  size="lg"
                  color={launch.upcoming ? 'blue' : launch.success ? 'green' : 'red'}
                  leftSection={
                    launch.upcoming ? 
                    <IconClock size={16} /> : 
                    launch.success ? 
                    <IconCheck size={16} /> : 
                    <IconX size={16} />
                  }
                >
                  {launch.upcoming ? 'Upcoming' : launch.success ? 'Success' : 'Failed'}
                </Badge>
                
                <Badge size="lg" color="gray">Flight #{launch.flight_number}</Badge>
              </Group>
            </Flex>
          </Grid.Col>
          
          <Grid.Col span={{ base: 12, md: 8 }}>
            <Title order={1} mb="xs">{launch.name}</Title>
            
            <Group mb="md">
              <Text color="dimmed" size="sm" display="flex" align="center">
                <IconCalendar size={16} style={{ marginRight: '0.3rem' }} />
                {formatDate(launch.date_utc)}
              </Text>
            </Group>
            
            <Text mb="lg">
              {launch.details || 'No detailed description available for this launch.'}
            </Text>
            
            {/* External links */}
            <Group mb="lg">
              {launch.links.webcast && (
                <Button 
                  component="a" 
                  href={launch.links.webcast} 
                  target="_blank" 
                  leftSection={<IconBrandYoutube size={16} />}
                  variant="outline"
                >
                  Webcast
                </Button>
              )}
              
              {launch.links.wikipedia && (
                <Button 
                  component="a" 
                  href={launch.links.wikipedia} 
                  target="_blank" 
                  leftIcon={<IconWorld size={16} />}
                  variant="outline"
                >
                  Wikipedia
                </Button>
              )}
              
              {launch.links.article && (
                <Button 
                  component="a" 
                  href={launch.links.article} 
                  target="_blank" 
                  leftSection={<IconLink size={16} />}
                  variant="outline"
                >
                  Article
                </Button>
              )}
            </Group>
          </Grid.Col>
        </Grid>
      </Paper>
      
      {/* Tabs for different sections */}
      <Tabs defaultValue="rocket" mb="xl">
        <Tabs.List mb="lg">
          <Tabs.Tab value="rocket" leftSection={<IconRocket size={16} />}>
            Rocket Details
          </Tabs.Tab>
          <Tabs.Tab value="images" leftSection={<IconPhoto size={16} />}>
            Images
          </Tabs.Tab>
          <Tabs.Tab value="mission" leftSection={<IconInfoCircle size={16} />}>
            Mission Info
          </Tabs.Tab>
        </Tabs.List>
        
        {/* Rocket Details Tab (Enriched Data) */}
        <Tabs.Panel value="rocket">
          {launch.rocketDetails ? (
            <Grid>
              <Grid.Col span={{ base: 12, md: 4 }}>
                <Card shadow="sm" padding="lg" radius="md" withBorder h="100%">
                  <Title order={2} mb="md">{launch.rocketDetails.name}</Title>
                  <Text mb="md">{launch.rocketDetails.description}</Text>
                  
                  <List spacing="sm">
                    <List.Item icon={<ThemeIcon color="blue" size={20} radius="xl"><IconInfoCircle size={12} /></ThemeIcon>}>
                      Type: {launch.rocketDetails.type}
                    </List.Item>
                    <List.Item icon={<ThemeIcon color="blue" size={20} radius="xl"><IconInfoCircle size={12} /></ThemeIcon>}>
                      First Flight: {launch.rocketDetails.first_flight}
                    </List.Item>
                    <List.Item icon={<ThemeIcon color="blue" size={20} radius="xl"><IconInfoCircle size={12} /></ThemeIcon>}>
                      Success Rate: {launch.rocketDetails.success_rate_pct}%
                    </List.Item>
                    <List.Item icon={<ThemeIcon color="blue" size={20} radius="xl"><IconInfoCircle size={12} /></ThemeIcon>}>
                      Cost Per Launch: ${launch.rocketDetails.cost_per_launch.toLocaleString()}
                    </List.Item>
                    <List.Item icon={<ThemeIcon color="blue" size={20} radius="xl"><IconInfoCircle size={12} /></ThemeIcon>}>
                      Status: {launch.rocketDetails.active ? 'Active' : 'Inactive'}
                    </List.Item>
                  </List>
                  
                  {launch.rocketDetails.wikipedia && (
                    <Button 
                      component="a"
                      href={launch.rocketDetails.wikipedia}
                      target="_blank"
                      variant="light"
                      fullWidth
                      mt="lg"
                      leftSection={<IconWorld size={16} />}
                    >
                      Read More on Wikipedia
                    </Button>
                  )}
                </Card>
              </Grid.Col>
              
              <Grid.Col span={{ base: 12, md: 4 }}>
                <Card shadow="sm" padding="lg" radius="md" withBorder h="100%">
                  <Title order={3} mb="md">Specifications</Title>
                  
                  <Stack gap="md">
                    <Box>
                      <Text fw={500}>Height</Text>
                      <Text>{launch.rocketDetails.height.meters} m ({launch.rocketDetails.height.feet} ft)</Text>
                    </Box>
                    
                    <Box>
                      <Text fw={500}>Diameter</Text>
                      <Text>{launch.rocketDetails.diameter.meters} m ({launch.rocketDetails.diameter.feet} ft)</Text>
                    </Box>
                    
                    <Box>
                      <Text fw={500}>Mass</Text>
                      <Text>{launch.rocketDetails.mass.kg.toLocaleString()} kg ({launch.rocketDetails.mass.lb.toLocaleString()} lb)</Text>
                    </Box>
                    
                    <Box>
                      <Text fw={500}>Stages</Text>
                      <Text>{launch.rocketDetails.stages}</Text>
                    </Box>
                    
                    <Box>
                      <Text fw={500}>Boosters</Text>
                      <Text>{launch.rocketDetails.boosters}</Text>
                    </Box>
                  </Stack>
                </Card>
              </Grid.Col>
              
              <Grid.Col span={{ base: 12, md: 4 }}>
                <Card shadow="sm" padding="lg" radius="md" withBorder h="100%">
                  <Title order={3} mb="md">Engine Details</Title>
                  
                  <Stack gap="md">
                    <Box>
                      <Text fw={500}>Engines</Text>
                      <Text>{launch.rocketDetails.engines.number} × {launch.rocketDetails.engines.type}</Text>
                    </Box>
                    
                    <Box>
                      <Text fw={500}>Propellant</Text>
                      <Text>{launch.rocketDetails.engines.propellant_1} / {launch.rocketDetails.engines.propellant_2}</Text>
                    </Box>
                    
                    <Box>
                      <Text fw={500}>Thrust (Sea Level)</Text>
                      <Text>{launch.rocketDetails.engines.thrust_sea_level.kN.toLocaleString()} kN ({launch.rocketDetails.engines.thrust_sea_level.lbf.toLocaleString()} lbf)</Text>
                    </Box>
                    
                    <Box>
                      <Text fw={500}>Thrust (Vacuum)</Text>
                      <Text>{launch.rocketDetails.engines.thrust_vacuum.kN.toLocaleString()} kN ({launch.rocketDetails.engines.thrust_vacuum.lbf.toLocaleString()} lbf)</Text>
                    </Box>
                  </Stack>
                </Card>
              </Grid.Col>
            </Grid>
          ) : (
            <Alert icon={<IconInfoCircle size={16} />} color="blue">
              No rocket details available for this launch.
            </Alert>
          )}
        </Tabs.Panel>
        
        {/* Images Tab */}
        <Tabs.Panel value="images">
          {launch.links.flickr.original.length > 0 ? (
            <Grid>
              {launch.links.flickr.original.map((image, index) => (
                <Grid.Col key={index} span={{ base: 12, sm: 6, md: 4 }}>
                  <Image
                    src={image}
                    alt={`${launch.name} - Image ${index + 1}`}
                    radius="md"
                  />
                </Grid.Col>
              ))}
            </Grid>
          ) : (
            <Alert icon={<IconInfoCircle size={16} />} color="blue">
              No images available for this launch.
            </Alert>
          )}
        </Tabs.Panel>
        
        {/* Mission Info Tab */}
        <Tabs.Panel value="mission">
          <Stack gap="md">
            <Box>
              <Title order={3} mb="sm">Core Details</Title>
              {launch.cores.length > 0 ? (
                <Grid>
                  {launch.cores.map((core, index) => (
                    <Grid.Col key={index} span={{ base: 12, md: 6 }}>
                      <Card shadow="sm" padding="lg" radius="md" withBorder>
                        <Title order={4} mb="sm">Core #{index + 1}</Title>
                        <List spacing="xs">
                          <List.Item>Flight Number: {core.flight || 'N/A'}</List.Item>
                          <List.Item>Reused: {core.reused ? 'Yes' : 'No'}</List.Item>
                          <List.Item>Grid Fins: {core.gridfins ? 'Yes' : 'No'}</List.Item>
                          <List.Item>Legs: {core.legs ? 'Yes' : 'No'}</List.Item>
                          <List.Item>Landing Attempt: {core.landing_attempt ? 'Yes' : 'No'}</List.Item>
                          <List.Item>Landing Success: {
                            core.landing_attempt 
                              ? (core.landing_success ? 'Success' : 'Failed') 
                              : 'N/A'
                          }</List.Item>
                          <List.Item>Landing Type: {core.landing_type || 'N/A'}</List.Item>
                        </List>
                      </Card>
                    </Grid.Col>
                  ))}
                </Grid>
              ) : (
                <Text>No core details available.</Text>
              )}
            </Box>
            
            {launch.payloads && launch.payloads.length > 0 && (
              <Box>
                <Title order={3} mb="sm">Payloads</Title>
                <Text>This mission carried {launch.payloads.length} payload(s).</Text>
              </Box>
            )}
            
            {launch.launchpad && (
              <Box>
                <Title order={3} mb="sm">Launch Pad</Title>
                <Text>Launch pad ID: {launch.launchpad}</Text>
              </Box>
            )}
          </Stack>
        </Tabs.Panel>
      </Tabs>
    </Container>
  );
}