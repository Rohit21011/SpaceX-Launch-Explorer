// src/pages/HomePage.tsx
import { useNavigate } from 'react-router-dom';
import { Container, Title, Text, Button, Group, Paper, SimpleGrid, ThemeIcon, Center, Box, Image, Flex } from '@mantine/core';
import { IconRocket, IconAnchor, IconSatellite } from '@tabler/icons-react';
import useAuthStore from '../store/authStore';

export default function HomePage() {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  
  return (
    <Container size="lg" py="xl">
      <Title align="center" mb="md">Welcome to SpaceX Explorer</Title>
      
      <Text color="dimmed" align="center" mb="xl" size="lg">
        Explore SpaceX launches, rockets, and mission details
      </Text>
      
      {/* User welcome card */}
      <Paper shadow="sm" p="lg" withBorder mb="xl">
        <Group position="apart">
          <Box>
            <Text fw={500} size="lg">Welcome, {user?.username || 'User'}!</Text>
            <Text color="dimmed" size="sm">You're logged in as {user?.email}</Text>
          </Box>
          
          <Button 
            onClick={() => navigate('/launches')}
            leftIcon={<IconAnchor size={16} />}
          >
            Explore Launches
          </Button>
        </Group>
      </Paper>
      
      {/* Feature blocks */}
      <SimpleGrid cols={1} breakpoints={[{ minWidth: '768px', cols: 3 }]} spacing="xl" mt={50}>
        <Paper shadow="sm" p="lg" radius="md" withBorder h="100%">
          <Center mb="md">
            <ThemeIcon size={50} radius="md" color="blue">
              <IconRocket size={26} />
            </ThemeIcon>
          </Center>
          <Text ta="center" fw={700} mt="md">Rocket Database</Text>
          <Text ta="center" size="sm" color="dimmed" mt="sm">
            Browse detailed information about all SpaceX rockets, including technical specifications and flight history.
          </Text>
        </Paper>
        
        <Paper shadow="sm" p="lg" radius="md" withBorder h="100%">
          <Center mb="md">
            <ThemeIcon size={50} radius="md" color="green">
              <IconAnchor size={26} />
            </ThemeIcon>
          </Center>
          <Text ta="center" fw={700} mt="md">Launch Archives</Text>
          <Text ta="center" size="sm" color="dimmed" mt="sm">
            Explore past and upcoming SpaceX launches with detailed mission information and media.
          </Text>
        </Paper>
        
        <Paper shadow="sm" p="lg" radius="md" withBorder h="100%">
          <Center mb="md">
            <ThemeIcon size={50} radius="md" color="orange">
              <IconSatellite size={26} />
            </ThemeIcon>
          </Center>
          <Text ta="center" fw={700} mt="md">Mission Details</Text>
          <Text ta="center" size="sm" color="dimmed" mt="sm">
            Dive deep into mission specifics, including payloads, orbits, and launch outcomes.
          </Text>
        </Paper>
      </SimpleGrid>
      
      {/* CTA */}
      <Center mt={50}>
        <Button 
          size="lg" 
          onClick={() => navigate('/launches')}
          leftIcon={<IconRocket size={20} />}
        >
          Get Started
        </Button>
      </Center>
    </Container>
  );
}