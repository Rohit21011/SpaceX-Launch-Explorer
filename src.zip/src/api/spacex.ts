// src/api/spacex.ts
import { Launch, LaunchQueryParams, Rocket } from './types';
import { useAuthStore } from '../store/authStore';

const API_URL = 'https://api.spacexdata.com/v4';

/**
 * SpaceX API service
 * Uses the SpaceX REST API v4
 */
export const spacexApi = {
  /**
   * Get all launches with optional filtering
   * 
   * @param params Query parameters for filtering
   * @returns Promise with array of launches
   */
  getLaunches: async (params?: LaunchQueryParams): Promise<Launch[]> => {
    const token = useAuthStore.getState().token;
    
    const response = await fetch(`${API_URL}/launches/query`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      },
      body: JSON.stringify({
        query: params?.query || {},
        options: {
          limit: params?.limit || 20,
          page: params?.page || 1,
          sort: params?.sort || { date_utc: 'desc' },
          populate: ['rocket']
        }
      })
    });

    if (!response.ok) {
      throw new Error('Failed to fetch launches');
    }

    const data = await response.json();
    return data.docs;
  },

  /**
   * Get a single launch by ID
   * 
   * @param id Launch ID
   * @returns Promise with launch data
   */
  getLaunchById: async (id: string): Promise<Launch> => {
    const token = useAuthStore.getState().token;
    
    const response = await fetch(`${API_URL}/launches/${id}`, {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch launch');
    }

    return response.json();
  },

  /**
   * Get all rockets
   * 
   * @returns Promise with array of rockets
   */
  getRockets: async (): Promise<Rocket[]> => {
    const token = useAuthStore.getState().token;
    
    const response = await fetch(`${API_URL}/rockets`, {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch rockets');
    }

    return response.json();
  },

  /**
   * Get a single rocket by ID
   * 
   * @param id Rocket ID
   * @returns Promise with rocket data
   */
  getRocketById: async (id: string): Promise<Rocket> => {
    const token = useAuthStore.getState().token;
    
    const response = await fetch(`${API_URL}/rockets/${id}`, {
      headers: {
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      }
    });

    if (!response.ok) {
      throw new Error('Failed to fetch rocket');
    }

    return response.json();
  }
};