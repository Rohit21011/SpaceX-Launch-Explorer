// src/api/auth.ts
import { AuthResponse } from '../store/authStore';

// Simulated authentication service
// In a real application, this would call an actual backend API
export const authApi = {
  /**
   * Login with email and password
   * 
   * @param email User email
   * @param password User password
   * @returns Promise with authentication data
   */
  login: async (email: string, password: string): Promise<AuthResponse> => {
    // Simulated API call with delay
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        // Hardcoded credentials for demo purposes
        if (email === 'demo@example.com' && password === 'password') {
          resolve({
            user: {
              id: 'user-1',
              email: 'demo@example.com',
              name: 'Demo User'
            },
            token: 'mock-jwt-token-xyz123'
          });
        } else {
          reject(new Error('Invalid credentials'));
        }
      }, 800); // Simulate network delay
    });
  },
  
  /**
   * Register a new user
   * 
   * @param name User name
   * @param email User email
   * @param password User password
   * @returns Promise with authentication data
   */
  register: async (name: string, email: string, password: string): Promise<AuthResponse> => {
    // Simulated API call with delay
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          user: {
            id: 'new-user-' + Date.now(),
            email,
            name
          },
          token: 'mock-jwt-token-new-user-xyz123'
        });
      }, 800);
    });
  }
};