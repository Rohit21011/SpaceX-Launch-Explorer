// src/api/client.ts
import axios from 'axios';
import useAuthStore from '../store/authStore';

// Base URL for SpaceX API
const BASE_URL = 'https://api.spacexdata.com/v4';

// Create axios instance with base configuration
export const apiClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
apiClient.interceptors.request.use(
  (config) => {
    const token = useAuthStore.getState().token;
    
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    
    return config;
  },
  (error) => Promise.reject(error)
);

// Response interceptor for error handling
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    // Handle authentication errors globally
    if (error.response?.status === 401) {
      useAuthStore.getState().logout();
      window.location.href = '/login';
    }
    
    return Promise.reject(error);
  }
);

// src/api/types.ts
export interface Rocket {
  id: string;
  name: string;
  type: string;
  description: string;
  height: {
    meters: number;
    feet: number;
  };
  diameter: {
    meters: number;
    feet: number;
  };
  mass: {
    kg: number;
    lb: number;
  };
  first_stage: {
    engines: number;
    fuel_amount_tons: number;
    burn_time_sec: number | null;
  };
  second_stage: {
    engines: number;
    fuel_amount_tons: number;
    burn_time_sec: number | null;
  };
  engines: {
    number: number;
    type: string;
    version: string;
    layout: string | null;
    engine_loss_max: number | null;
    propellant_1: string;
    propellant_2: string;
    thrust_sea_level: {
      kN: number;
      lbf: number;
    };
    thrust_vacuum: {
      kN: number;
      lbf: number;
    };
  };
  images: string[];
  active: boolean;
  stages: number;
  boosters: number;
  cost_per_launch: number;
  success_rate_pct: number;
  first_flight: string;
  wikipedia: string;
}

export interface Launch {
  id: string;
  flight_number: number;
  name: string;
  date_utc: string;
  date_unix: number;
  date_local: string;
  date_precision: string;
  static_fire_date_utc: string | null;
  static_fire_date_unix: number | null;
  tbd: boolean;
  net: boolean;
  window: number | null;
  rocket: string;
  success: boolean | null;
  failures: {
    time: number;
    altitude: number | null;
    reason: string;
  }[];
  upcoming: boolean;
  details: string | null;
  fairings: {
    reused: boolean | null;
    recovery_attempt: boolean | null;
    recovered: boolean | null;
    ships: string[];
  } | null;
  crew: string[];
  ships: string[];
  capsules: string[];
  payloads: string[];
  launchpad: string;
  cores: {
    core: string | null;
    flight: number | null;
    gridfins: boolean | null;
    legs: boolean | null;
    reused: boolean | null;
    landing_attempt: boolean | null;
    landing_success: boolean | null;
    landing_type: string | null;
    landpad: string | null;
  }[];
  links: {
    patch: {
      small: string | null;
      large: string | null;
    };
    reddit: {
      campaign: string | null;
      launch: string | null;
      media: string | null;
      recovery: string | null;
    };
    flickr: {
      small: string[];
      original: string[];
    };
    presskit: string | null;
    webcast: string | null;
    youtube_id: string | null;
    article: string | null;
    wikipedia: string | null;
  };
  auto_update: boolean;
}

export interface LaunchWithRocket extends Launch {
  rocketDetails?: Rocket;
}

export interface PaginationOptions {
  page?: number;
  limit?: number;
}

export interface FilterOptions {
  upcoming?: boolean;
  success?: boolean;
  rocket?: string;
  startDate?: string;
  endDate?: string;
}

// src/api/endpoints.ts
import { apiClient } from './client';
import { Rocket, Launch, PaginationOptions, FilterOptions } from './types';

// Rockets Endpoints
export const getRockets = async (): Promise<Rocket[]> => {
  const response = await apiClient.get<Rocket[]>('/rockets');
  return response.data;
};

export const getRocketById = async (id: string): Promise<Rocket> => {
  const response = await apiClient.get<Rocket>(`/rockets/${id}`);
  return response.data;
};

// Launches Endpoints
export const getLaunches = async (
  pagination: PaginationOptions = { page: 1, limit: 10 },
  filters: FilterOptions = {}
): Promise<Launch[]> => {
  // Create query for SpaceX API
  const query = {
    query: {
      ...(filters.upcoming !== undefined && { upcoming: filters.upcoming }),
      ...(filters.success !== undefined && { success: filters.success }),
      ...(filters.rocket && { rocket: filters.rocket }),
      ...(filters.startDate || filters.endDate) && {
        date_utc: {
          ...(filters.startDate && { $gte: filters.startDate }),
          ...(filters.endDate && { $lte: filters.endDate }),
        },
      },
    },
    options: {
      page: pagination.page || 1,
      limit: pagination.limit || 10,
      sort: { date_utc: 'desc' },
      populate: ['rocket', 'launchpad', 'payloads'],
    },
  };

  const response = await apiClient.post<{ docs: Launch[]; totalDocs: number; limit: number; totalPages: number; page: number; }>('/launches/query', query);
  return response.data.docs;
};

export const getLaunchById = async (id: string): Promise<Launch> => {
  const response = await apiClient.get<Launch>(`/launches/${id}`);
  return response.data;
};

// Get Launch with Rocket details (enriched data)
export const getLaunchWithRocketDetails = async (id: string): Promise<LaunchWithRocket> => {
  const launch = await getLaunchById(id);
  
  // Get rocket details if the launch has a rocket ID
  if (launch.rocket) {
    const rocket = await getRocketById(launch.rocket);
    return {
      ...launch,
      rocketDetails: rocket
    };
  }
  
  return launch;
};