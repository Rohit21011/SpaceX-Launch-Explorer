// src/hooks/useRocketData.ts
import { useQuery } from '@tanstack/react-query';
import { getRockets, getRocketById } from '../api/endpoints';
import { Rocket } from '../api/types';

export const useRockets = () => {
  return useQuery<Rocket[], Error>({
    queryKey: ['rockets'],
    queryFn: () => getRockets(),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
};

export const useRocket = (id: string) => {
  return useQuery<Rocket, Error>({
    queryKey: ['rocket', id],
    queryFn: () => getRocketById(id),
    staleTime: 1000 * 60 * 5, // 5 minutes
    enabled: !!id, // Only fetch when id is available
  });
};

// src/hooks/useLaunchData.ts
import { useQuery } from '@tanstack/react-query';
import { getLaunches, getLaunchById, getLaunchWithRocketDetails } from '../api/endpoints';
import { Launch, LaunchWithRocket, PaginationOptions, FilterOptions } from '../api/types';

export const useLaunches = (
  pagination: PaginationOptions = { page: 1, limit: 10 },
  filters: FilterOptions = {}
) => {
  return useQuery<Launch[], Error>({
    queryKey: ['launches', pagination, filters],
    queryFn: () => getLaunches(pagination, filters),
    keepPreviousData: true, // Keep previous data while fetching new data
  });
};

export const useLaunch = (id: string) => {
  return useQuery<Launch, Error>({
    queryKey: ['launch', id],
    queryFn: () => getLaunchById(id),
    enabled: !!id, // Only fetch when id is available
  });
};

export const useLaunchWithRocket = (id: string) => {
  return useQuery<LaunchWithRocket, Error>({
    queryKey: ['launchWithRocket', id],
    queryFn: () => getLaunchWithRocketDetails(id),
    enabled: !!id, // Only fetch when id is available
  });
};

// src/hooks/useAuth.ts
import { useState, useCallback } from 'react';
import useAuthStore from '../store/authStore';
import { AuthResponse } from '../store/authStore';

export const useAuth = () => {
  const { isAuthenticated, user, token, login, logout } = useAuthStore();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Mock login function - in a real app, this would call your actual API
  const handleLogin = useCallback(async (email: string, password: string) => {
    try {
      setLoading(true);
      setError(null);
      
      // Simulate API request
      await new Promise(resolve => setTimeout(resolve, 800));
      
      // Demo credentials check
      if (email === 'demo@example.com' && password === 'password') {
        const userData: AuthResponse = {
          user: {
            id: '1',
            username: 'demouser',
            email: 'demo@example.com',
            role: 'user'
          },
          token: 'mock-jwt-token-would-come-from-server'
        };
        
        login(userData);
        return true;
      } else {
        setError('Invalid email or password');
        return false;
      }
    } catch (err) {
      setError('An unexpected error occurred. Please try again.');
      console.error('Login error:', err);
      return false;
    } finally {
      setLoading(false);
    }
  }, [login]);

  const handleLogout = useCallback(() => {
    logout();
  }, [logout]);

  return {
    isAuthenticated,
    user,
    token,
    loading,
    error,
    login: handleLogin,
    logout: handleLogout,
  };
};