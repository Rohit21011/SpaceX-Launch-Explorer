// src/hooks/useAuth.ts
import { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuthStore } from '../store/authStore';
import { authApi } from '../api/auth';

/**
 * Custom hook for authentication operations
 * Provides login, logout, and auth state management
 */
export const useAuth = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  const { 
    isAuthenticated, 
    user, 
    token,
    login: storeLogin,
    logout: storeLogout 
  } = useAuthStore();

  /**
   * Login with email and password
   * 
   * @param email User email
   * @param password User password
   * @param redirectTo Optional redirect path after login
   */
  const login = async (
    email: string, 
    password: string, 
    redirectTo?: string
  ) => {
    setLoading(true);
    setError(null);
    
    try {
      const userData = await authApi.login(email, password);
      storeLogin(userData);
      
      // Navigate to redirectTo or to the page user was trying to access
      const from = (location.state as any)?.from?.pathname || redirectTo || '/';
      navigate(from, { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Register a new user
   * 
   * @param name User name
   * @param email User email
   * @param password User password
   * @param redirectTo Optional redirect path after registration
   */
  const register = async (
    name: string,
    email: string,
    password: string,
    redirectTo?: string
  ) => {
    setLoading(true);
    setError(null);
    
    try {
      const userData = await authApi.register(name, email, password);
      storeLogin(userData);
      
      // Navigate to dashboard or specified route
      navigate(redirectTo || '/', { replace: true });
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Registration failed');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Logout the current user
   * 
   * @param redirectTo Optional redirect path after logout
   */
  const logout = (redirectTo?: string) => {
    storeLogout();
    navigate(redirectTo || '/login', { replace: true });
  };

  return {
    isAuthenticated,
    user,
    token,
    login,
    register,
    logout,
    loading,
    error
  };
};